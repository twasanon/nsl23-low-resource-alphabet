# NSL23 Manuscript Claim Ledger

This ledger is the Version 1 manuscript's fail-closed evidence map. A quantitative or methodological claim may enter the article only when the evidence column points to an existing source or generated artifact. S1/S2 results are exploratory cross-signer development evidence because those same folds informed later representation and loss choices; they are not an untouched confirmatory test. Version 2 has a separate prospective protocol in `VERSION2.md`.

| Claim family | Permitted wording / boundary | Evidence | Status |
|---|---|---|---|
| Dataset provenance | NSL23 version 2 is available on Zenodo under CC BY 4.0, DOI 10.5281/zenodo.10478554. | `artifacts/audit/archive_checksums.json`; Zenodo record 10478554 | verified |
| Dataset scale | The release contains 630 videos representing 1,205 claimed gesture instances, 49 alphabet classes, and 14 volunteers. “Instances” must not be called separately labelled clips. | Sunuwar et al. (2024); `Details Dataset.docx`; `artifacts/audit/nsl23_manifest_summary.json` | verified |
| File integrity | All five official files match the release byte counts and MD5 values. | `artifacts/audit/archive_checksums.json`; output of `scripts/verify_primary_protocol.py --verify-archive-hashes` | verified |
| Primary sample definition | The primary analysis uses 375 original, individually labelled clips. It excludes all 23 aggregate sources and all cropped/preprocessed derivatives. | `data/manifests/nsl23_manifest_all.csv`; `artifacts/audit/aggregate_exclusions_summary.json`; `PROTOCOL.md` | verified |
| Aggregate exclusion | Aggregate recordings lack released gesture timestamps; equal-duration candidate bins did not reliably preserve class identity on visual review. Do not claim the candidate segments are ground truth. | `annotations/aggregate_source_review.csv`; `artifacts/segment_review/`; `artifacts/audit/aggregate_exclusions.csv` | verified |
| Cross-signer development protocol | Fold 1 holds out S1; fold 2 holds out S2. Each fold has 277 training and 98 evaluation clips, and train/evaluation both contain all 49 classes. “Held out” means absent from that run's training data, not untouched across the full study. | `configs/isolated_twofold_protocol.json`; `artifacts/audit/isolated_twofold_summary.json`; `scripts/verify_primary_protocol.py` | verified |
| Test conditions | Each held-out signer has one bright and one dark original clip for every class. Condition results are descriptive, not causal illumination effects. | cached fold manifests; `artifacts/audit/isolated_twofold_summary.json` | verified |
| External validity | The complete-alphabet unseen-signer test covers two signers only. It does not estimate population-wide signer generalization or generalization to prepared/outdoor settings. | `PROTOCOL.md`; fold manifests | verified |
| Primary-set composition | Only S1 and S2 contribute original isolated vowels; within either fold, vowel training comes from the other held-out-capable signer alone. The five additional isolated signers contribute prepared consonants only. | `artifacts/audit/primary_set_composition.json`; primary manifest | verified |
| Input sampling | Sixteen temporal-bin-center frames are aspect-preserving letterboxed to 224×224; no horizontal flip is used; photometric augmentation is sequence-consistent and training-only. | `src/nsl23/frame_cache.py`; `src/nsl23/dataset.py`; `configs/experiment_local_m4.json` | verified |
| Model definitions | RGB models use the same frozen ImageNet-1K V2 MobileNetV2 encoder. Landmark models use 64-D MediaPipe frames. Parameter counts must match the instantiated checkpoints. | `src/nsl23/models.py`; run `metrics.json`; Figure 2 | verified |
| Optimization | Seeds 17/42/73, batch 8, 30 fixed epochs, class-weighted cross entropy, AdamW 3e-4, weight decay 1e-4, cosine annealing, deterministic algorithms. | `configs/experiment_local_m4.json`; `src/nsl23/train.py`; run artifacts | verified |
| Model selection | There is no validation set or early stopping. Only the fixed epoch-30 checkpoint is tested. Do not call `best_checkpoint.pt` validation-selected. | `PROTOCOL.md`; `selection_policy` in all run metrics/checkpoints | verified |
| Test-access chronology | A one-epoch software smoke test accessed held-out S1 after protocol/configuration files were fixed but before their exact hash snapshot; scores were not used for any design or selection decision. | `artifacts/audit/test_access_timeline.json`; file modification times | verified |
| Follow-on development reuse | The S1/S2 results later informed joint-angle, prototypical-loss, crop, fusion, and enrollment analyses. All Version 1 percentages therefore remain exploratory development estimates. | experiment chronology; improvement scripts and artifacts; `PAPER_DIRECTION.md` | verified |
| Primary performance | Report top-1 accuracy and macro-F1 from 196 pooled out-of-fold clips per seed, then mean and sample SD over three seeds. Also expose fold-specific values. | `artifacts/results/model_summary.csv`; `pooled_out_of_fold_by_seed.csv`; `fold_summary.csv` | verified |
| Uncertainty | Clip-level class-stratified bootstrap intervals are descriptive; they do not address signer-population uncertainty with only two held-out signers. | per-run metrics; `artifacts/results/primary_results_summary.json` | verified |
| Architecture comparison | Use descriptive paired seed differences. Do not claim statistical significance or state of the art. | `artifacts/results/paired_differences_summary.csv` | verified |
| Lighting breakdown | Report bright versus dark scores from pre-specified out-of-fold subsets with mean and SD over seeds. | `artifacts/results/condition_summary.csv`; Figure 5 | verified |
| Runtime | Report synchronized batch-one model-only and end-to-end median/p95 latency on the Apple M4 MPS host. Do not call RGB clip latency streaming or real-time performance. | `artifacts/runtime/*/runtime.json` | verified |
| Landmark representation | MediaPipe Hands 0.10.14, wrist-relative xyz, 64-D frames, 97.8% frame detections, 0 empty clips. | `src/nsl23/landmarks.py`; `artifacts/audit/landmark_detection_summary.json` | verified |
| Landmark performance | Landmark BiLSTM 24.8% ± 4.0% pooled accuracy; MLP 18.0% ± 2.1%; same 196 clips/seed as RGB. | `artifacts/results/model_summary.csv`; 30-run `primary_results_summary.json` | verified |
| Joint-angle CE | xyz+angle BiLSTM 37.9% ± 2.4% pooled; MLP 22.4% ± 3.1%. Same folds/seeds. | `artifacts/runs/improvements/*/landmark_*/**/metrics.json`; `artifacts/results/improvements/summary.json` | verified |
| Prototypical encoder | Exploratory S1/S2 estimate: xyz+angle Proto-BiLSTM 59.4% ± 3.3% pooled; xyz-only proto 55.8% ± 1.8%. Evaluation uses training-set prototypes only; neither number is untouched confirmation. | proto `metrics.json`; `scripts/train_protonet.py` | verified |
| Cropped-hand CNN | Frozen MobileNetV2 on MediaPipe hand crops: 19.2% ± 1.3%. Fusion with proto is 59.7% ± 3.6% and is not a headline gain. | crop `metrics.json`; `artifacts/results/improvements/fusion_proto_*.json` | verified |
| Closed 1-shot | Other lighting of the test signer, 49-way: 76.2% ± 4.2% (xyz BiLSTM), 78.2% ± 2.8% (angle BiLSTM), 73.0% ± 1.5% (proto). Do not report `enroll_replace_class` as 1-shot. | `artifacts/results/improvements/enrollment_*.json` | verified |
| Alternative exams | Same proto encoder only: top-3 85.5% ± 6.0%; top-5 91.3% ± 4.0%; 36-way consonants 65.7% ± 3.6%; 5-way 1-shot unseen 90.6% ± 2.5%; 5-way same-signer 93.3% ± 1.5%. Must name the exam. Do not quote 5-way as 49-way alphabet accuracy. | `artifacts/results/improvements/alternative_protocols.json`; Table `tab:protocols` | verified |
| Webcam loop | Sliding-window MediaPipe + prototypical landmark encoder on NSL23 `.MOV` streams: 33–42 FPS on Apple M4 CPU (proto S1-A 39.6 FPS). Do not equate FPS with alphabet accuracy. | `scripts/webcam_demo.py`; `artifacts/runtime/webcam_heldout_s1_A.json`; `artifacts/runtime/webcam_proto_heldout_s1_A.json` | verified |
| Reproducibility | The code, configurations, notebook, manifests builders, audit scripts, and compact supplementary bundle reproduce the analysis from the official archives. | `NSL23_CNN_Transformer_Reproducibility.ipynb`; `NSL23_reproducibility_bundle.zip`; protocol snapshot | verified |

## Prohibited claims

- “93.5% accuracy” or any number not present in final result artifacts.
- “State of the art,” “first,” or “novel architecture” without a directly comparable literature basis.
- Quoting 5-way 1-shot (~91%) or top-5 (~91%) as 49-way isolated alphabet accuracy.
- “1,205 isolated clips.”
- Dataset collection “in Nepal.” The NSL23 recordings were collected in Sikkim, India.
- “Real-time system,” “streaming recognition,” or deployment readiness based only on offline clip latency.
- Generalization to 14 unseen signers, outdoor scenes, prepared backgrounds, continuous signing, or the broader Deaf/NSL-user population.
- Causal claims about lighting, architecture, or expertise from this observational, two-test-signer protocol.
- Describing the Version 1 S1/S2 results as an untouched, final, confirmatory, or preregistered test.
